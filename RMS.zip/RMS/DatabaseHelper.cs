﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
    public class DatabaseHelper
    {
        private string connectionString;

        public DatabaseHelper(string connStr)
        {
            connectionString = connStr;
        }

        public bool CheckIfDealExists(string dealName)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT deal_name FROM Deal WHERE deal_name = @dealName", con);
                cmd.Parameters.AddWithValue("@dealName", dealName);
                SqlDataReader reader = cmd.ExecuteReader();
                return reader.Read();
            }
        }

        public bool CheckIfDealDateExists(DateTime dealDate)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT deal_date FROM Deal WHERE deal_date = @dealDate", con);
                cmd.Parameters.AddWithValue("@dealDate", dealDate);
                SqlDataReader reader = cmd.ExecuteReader();
                return reader.Read();
            }
        }

        public void InsertDeal(string dealName, DateTime dealDate, decimal dealPrice)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "INSERT INTO Deal (deal_name, deal_date, deal_price) VALUES (@dealName, @dealDate, @dealPrice)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dealName", dealName);
                cmd.Parameters.AddWithValue("@dealDate", dealDate);
                cmd.Parameters.AddWithValue("@dealPrice", dealPrice);
                cmd.ExecuteNonQuery();
            }
        }

        public void InsertMenuDeal(string dealName, string itemName)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "INSERT INTO menuDeal (deal_name, itemNo) VALUES (@dealName, (SELECT itemNo FROM Menu WHERE itemName = @itemName))";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dealName", dealName);
                cmd.Parameters.AddWithValue("@itemName", itemName);
                cmd.ExecuteNonQuery();
            }
        }

        public List<string> GetMenuItems()
        {
            List<string> menuItems = new List<string>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT itemName FROM Menu", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    menuItems.Add(reader.GetString(0));
                }
            }
            return menuItems;
        }


    }
}
