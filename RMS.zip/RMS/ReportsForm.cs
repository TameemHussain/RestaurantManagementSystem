﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RMS
{
    public partial class ReportsForm : Form
    {
        // Connection string for DATABASE1.MDF
        private string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DATABASE1.MDF;Integrated Security=True";

        public ReportsForm()
        {
            InitializeComponent();
        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {
            // Any initialization code can go here
        }

        // This method should be connected to your "View Today's Total" button click event
        private void btnViewTodaysSales_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM DailySales WHERE CONVERT(date, SaleDate) = CONVERT(date, GETDATE())";

                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                    }
                    else
                    {
                        MessageBox.Show("No sales found for today.");
                        dataGridView1.DataSource = null; // Clear the grid if no data
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching today's sales: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Grid view cell click handling if needed
        }
    }
}